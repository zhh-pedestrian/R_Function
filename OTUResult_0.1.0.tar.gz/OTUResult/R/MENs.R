#' Title
#'
#' @param file_name
#' @param tax_name
#' @param otu_threshold
#' @usage network_analysis(file_name = otu, tax_name = tax, otu_threshold = 0.001)
#' @return
#' @export
#'
#' @examples
network_analysis <- function(file_name, tax_name, otu_threshold) {
  library("preprocessCore")
  library("impute")
  library("WGCNA")
  library("igraph")
  library("ggClusterNet")

  otu <- file_name
  otus <- otu[rowSums(otu) / sum(otu) > otu_threshold,]

  print(paste("原始表格中otu个数为", nrow(otu),"筛选后otu的个数为", nrow(otus)))
  response <- readline("若继续分析，请输入'yes'，输入'no'返回: ")
  if (response != "yes") {
    print("分析中止。")
    return(NULL)
  }

  print("正在计算otu之间的相关性、显著性...")
  occor <- WGCNA::corAndPvalue(t(otus), use = 'pairwise', method = 'spearman')
  CorrDF <- function(cormat, pmat) {
    ut <- upper.tri(cormat)
    data.frame(
      Source = rownames(cormat)[col(cormat)[ut]],
      Target = rownames(cormat)[row(cormat)[ut]],
      cor = (cormat)[ut],
      p = pmat[ut]
    )
  } # 设置函数构建网络(和melt类似)

  edge <- CorrDF(occor$cor , occor$p)
  ## 设置 rho/p 阈值，优化edge文件
  Edge <- edge[(edge$cor > 0.5 | edge$p < 0.05), ]
  ## 删除存在于Target但不存在于Source中的OTU
  Edge1 <- Edge[Edge$Target %in% Edge$Source,]

  # 利用边文件获取节点文件
  node <- as.data.frame(as.data.frame(Edge1[,1])[!duplicated(as.data.frame(Edge1[,1])),])
  # 等价于
  # node <- as.matrix(unique(Edge1[,1]))
  print("已成功计算出Node、Edge。")

  ## 节点文件美化，添加注释
  tax <- read.csv(file = tax_name)
  colnames(node)[1] <- "ID"
  colnames(tax)[1] <- "ID"
  Node <- merge(node, tax, by ="ID")
  Node$Label <- Node$ID

  output_name <- gsub(".csv", "", file_name)
  write.csv(Node, file = paste0(output_name, "_节点表格.csv"), fileEncoding = "utf-8", row.names = FALSE)
  write.csv(Edge1, file = paste0(output_name, "_边表格.csv"), fileEncoding = "utf-8", row.names = FALSE)

  print("Node、Edge文件已导出。")

  library(igraph)
  library(ggClusterNet)
  rho <- occor$cor
  netClu <- modulGroup(cor = rho,cut = NULL,method = "cluster_fast_greedy" )
  netnode <- merge(node, netClu, by = "ID")
  write.csv(netnode, file = paste0(output_name, "_聚类文件.csv"), fileEncoding = "utf-8", row.names = FALSE)
  print("已成功计算并导出聚类文件。")

  result <- nodeEdge(cor = rho)
  dat_edge = result[[1]]
  #--提取节点文件
  dat_node = result[[2]]
  dat_igraph  = igraph::graph_from_data_frame(dat_edge, directed = FALSE, vertices = dat_node)
  print("请选择您所需要的网络属性类型:")
  print("输入 1: 计算12种网络属性，时长较短")
  print("输入 2: 计算完整版16种网络属性，但时长较长")
  property_choice <- as.integer(readline(prompt = "请输入选项: "))

  if (property_choice == 1) {
    # 计算 12 种网络属性
    dat = net_properties(igraph)
  } else if (property_choice == 2) {
    # 计算 16 种网络属性
    dat = net_properties.2(igraph,n.hub = T)
  } else {
    print("无效选项。分析中止。")
    return(NULL)
  }
  write.csv(dat, file = paste0(output_name, "_网络属性.csv"), fileEncoding = "utf-8")
  print("已成功计算并导出网络属性。")
  print("数据处理完成。")
}
