#' @title Data analysis for alpha, beta, composition structure, and AVD.
#' @description Data analysis for alpha, beta, composition structure, and AVD.
#'
#'
#' @param file_otu
#' @param file_tax
#' @param file_group
#'
#' @return
#' @export
#' @usage data_analysis(file_out = otu.csv, file_tax = tax.csv, file_group = group.csv)
#' @examples
#' \donttest{
#' data_analysis(file_out = otu.csv, file_tax = tax.csv, file_group = group.csv)
#' }
#'
data_analysis <- function(file_otu, file_tax, file_group){
  library(ggplot2)
  library(ade4)
  library(vegan)
  library(tidyverse)
  library(lattice)
  library(MASS)

  ## 计算Alpha多样性-----
  if (!file.exists("alpha analysis result")) {
    dir.create("alpha analysis result")
  }
  data <- file_otu
  est <- estimateR(t(data))
  richness <- est[1,]
  shannon <- diversity(t(data), index = "shannon")
  if (is.na(richness[1])) {
    cat("未成功计算出 Richness.\n")
    return(NULL)
  }
  alpha <- cbind(richness, shannon)

  result_file <- file.path("alpha analysis result", "alpha.csv")
  write.csv(alpha, file = result_file)
  cat("Richness and Shannon computed successfully, the result saved in <alpha analysis result>\n")

  if (!file.exists("bata analysis result")) {
    dir.create("bata analysis result")
  }

  ## 计算bata多样性-----
  dist <- vegdist(t(as.matrix(data)), method = "euclidean", na.rm = TRUE)
  pcoa <- dudi.pco(dist, scannf = FALSE, nf = 2)
  pcoa_result <- pcoa$li
  x <- round(pcoa$eig[1] / sum(pcoa$eig) * 100, 2)
  y <- round(pcoa$eig[2] / sum(pcoa$eig) * 100, 2)

  result_file <- file.path("bata analysis result", "bata.csv")
  write.csv(pcoa_result, file = result_file,)
  cat("PCoA coordinates computed successfully, the result saved in <bata analysis result>\n")
  cat("PCoA 1 is", x, "% ；PCoA 2 is", y, "%\n")

  ## 计算稳定性AVD------
  if (!file.exists("average variation degree (AVD)")) {
    dir.create("average variation degree (AVD)")
  }

  data1 <- t(data)
  col_mean <- apply(data1, 1, mean)
  col_sd <- apply(data1, 1, sd)
  myfun <- function(x, y, z) {
    return(abs(x - y) / z)
  }
  newdata <- apply(data1, 2, myfun, col_mean, col_sd)
  avd <- apply(newdata, 1, sum) / (ncol(data1) * rowSums(data1 != 0))
  avd_df <- data.frame(avd)
  if (any(is.na(avd))) {
    cat("未成功计算出稳定性 AVD.\n")
    return(NULL)
  }
  result_file <- file.path("average variation degree (AVD)", "avd.csv")
  write.csv(avd_df, file = result_file)
  cat("AVD computed successfully.\n")

  data_all <- cbind(alpha, pcoa_result, avd_df)
  write.csv(data_all, file = "data_analysis.csv")
  cat("Successfully save the results of alpha, beta, and avd as a !!! data_analysis.csv !!! file, stored in the current location, and use the `getwd()` function to check.\n")

  ##组成结构----
  if (!file.exists("community composition analyses")) {
    dir.create("community composition analyses")
  }

  otu <- file_otu
  tax <- file_tax
  otu$ID <- rownames(otu)
  tax$ID <- rownames(tax)
  df <- merge(otu,tax,by = "ID")
  cat("\n数据集 df 如下所示：\n")
  x <- head(df)[1,]
  print(x)

  cat("\n!!!请选择需要分析的分类水平，如 'Phylum': !!!\n")
  user_input <- readline()

  if (user_input %in% colnames(df)) {
    rank <- df %>%
      dplyr::group_by(across(all_of(user_input))) %>%
      dplyr::summarise_if(is.numeric, sum, na.rm = TRUE)

    cat("已选择的分类水平为:", user_input, "\n")
  } else {
    cat("错误：输入的内容不是有效的列名，请重新输入。\n")
    # 可以在这里加入适当的错误处理或要求用户重新输入的逻辑
  }

  result_file <- file.path("community composition analyses", "community_composition.csv")
  write.csv(rank, file = result_file, row.names = FALSE)
  cat("Successful calculation of composition structure.\n")

  ## LDA分析-----
  if (!file.exists("linear discriminant analysis effect size (LEfSe)")) {
    dir.create("linear discriminant analysis effect size (LEfSe)")
  }
  otu <- file_otu
  tax <- file_tax
  group <- file_group

  dataset <- microeco::microtable$new(sample_table = group,
                                      otu_table = otu,
                                      tax_table = tax)
  lefse <- microeco::trans_diff$new(dataset = dataset,
                                    method = "lefse",
                                    group = "group",
                                    alpha = 0.1,
                                    lefse_subgroup = NULL)
  res <- lefse$res_diff

  result_file <- file.path("linear discriminant analysis effect size (LEfSe)", "LDA.csv")
  write.csv(res, file = result_file)
  cat("Successful calculation of LEfSe.\n")
}





